package com.example.sistema_copadomundo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaCopadomundoApplicationTests {

	@Test
	void contextLoads() {
	}

}
