package com.example.sistema_copadomundo.Service;

import com.example.sistema_copadomundo.Model.Partida;
import com.example.sistema_copadomundo.Model.Selecao;
import com.example.sistema_copadomundo.Repository.PartidaRepository;
import com.example.sistema_copadomundo.Repository.SelecaoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor

public class PartidaService {

    private final PartidaRepository partidaRepository;
    private final SelecaoRepository selecaoRepository;

    public Partida registrar(Partida partida) {
        Selecao selecao =
                selecaoRepository.findById(partida.getSelecao().getId())
                        .orElseThrow(() -> new RuntimeException("Seleção não encontrada"));

        if (selecao.getJogadoresDisponiveis() < partida.getQuantidade()) {
            throw new RuntimeException("Quantidade indisponível de jogadores");

        }

        selecao.setJogadoresDisponiveis(
                selecao.getJogadoresDisponiveis() - partida.getQuantidade()
        );

        selecaoRepository.save(selecao);
        partida.setSelecao(selecao);
        return partidaRepository.save(partida);

    }

}
