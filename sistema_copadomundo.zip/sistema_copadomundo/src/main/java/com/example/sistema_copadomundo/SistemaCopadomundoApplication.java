package com.example.sistema_copadomundo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaCopadomundoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaCopadomundoApplication.class, args);
	}

}
