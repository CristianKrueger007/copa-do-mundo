package com.example.sistema_copadomundo.Repository;

import com.example.sistema_copadomundo.Model.Convocacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConvocacaoRepository extends JpaRepository<Convocacao, Long> {
}
